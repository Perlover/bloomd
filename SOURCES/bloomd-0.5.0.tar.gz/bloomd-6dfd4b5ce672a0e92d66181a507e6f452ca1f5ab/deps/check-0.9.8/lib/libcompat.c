#include "libcompat.h"

/* silence warnings about an empty library */
void
ck_do_nothing (void)
{
  assert (0);
}
